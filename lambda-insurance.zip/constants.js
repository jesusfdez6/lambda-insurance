module.exports = {
    NAME_LAMBDA : "INSURANCE"
}